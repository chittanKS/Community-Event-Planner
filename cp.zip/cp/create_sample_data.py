#!/usr/bin/env python3
"""
Sample data creation script for EventHub
Run this script to populate the database with sample events and users
"""

import os
import sys
from datetime import datetime, date, timedelta
import random

# Add the project directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import app, db, User, Event, RSVP
from werkzeug.security import generate_password_hash

def create_sample_users():
    """Create sample users"""
    users_data = [
        {
            'name': 'John Smith',
            'email': 'john@example.com',
            'password': 'password123'
        },
        {
            'name': 'Sarah Johnson',
            'email': 'sarah@example.com',
            'password': 'password123'
        },
        {
            'name': 'Mike Chen',
            'email': 'mike@example.com',
            'password': 'password123'
        },
        {
            'name': 'Emily Davis',
            'email': 'emily@example.com',
            'password': 'password123'
        },
        {
            'name': 'Alex Thompson',
            'email': 'alex@example.com',
            'password': 'password123'
        }
    ]
    
    created_users = []
    for user_data in users_data:
        # Check if user already exists
        existing_user = User.query.filter_by(email=user_data['email']).first()
        if not existing_user:
            user = User(
                name=user_data['name'],
                email=user_data['email'],
                password=generate_password_hash(user_data['password'])
            )
            db.session.add(user)
            created_users.append(user)
            print(f"Created user: {user_data['name']}")
        else:
            created_users.append(existing_user)
            print(f"User already exists: {user_data['name']}")
    
    db.session.commit()
    return created_users

def create_sample_events(users):
    """Create sample events"""
    events_data = [
        {
            'title': 'Tech Conference 2024',
            'description': 'Join us for the biggest tech conference of the year! Featuring keynote speakers from leading tech companies, workshops on emerging technologies, and networking opportunities with industry professionals.',
            'date': date.today() + timedelta(days=15),
            'time': datetime.strptime('09:00', '%H:%M').time(),
            'location': 'Convention Center, Downtown',
            'category': 'conference'
        },
        {
            'title': 'Python Workshop for Beginners',
            'description': 'Learn Python programming from scratch! This hands-on workshop covers variables, data types, control flow, functions, and basic object-oriented programming. No prior experience required.',
            'date': date.today() + timedelta(days=7),
            'time': datetime.strptime('14:00', '%H:%M').time(),
            'location': 'Tech Hub, Room 201',
            'category': 'workshop'
        },
        {
            'title': 'Startup Meetup',
            'description': 'Connect with fellow entrepreneurs, share ideas, and discuss challenges in the startup ecosystem. Great opportunity to find co-founders and investors.',
            'date': date.today() + timedelta(days=3),
            'time': datetime.strptime('18:30', '%H:%M').time(),
            'location': 'Innovation Cafe',
            'category': 'meetup'
        },
        {
            'title': 'Community Yoga Session',
            'description': 'Relax and rejuvenate with our weekly community yoga session. All skill levels welcome. Bring your own mat and water bottle.',
            'date': date.today() + timedelta(days=1),
            'time': datetime.strptime('07:00', '%H:%M').time(),
            'location': 'Central Park',
            'category': 'sports'
        },
        {
            'title': 'Jazz Night at Blue Note',
            'description': 'An evening of smooth jazz featuring local musicians. Enjoy live performances while sipping on fine wines and delicious appetizers.',
            'date': date.today() + timedelta(days=10),
            'time': datetime.strptime('20:00', '%H:%M').time(),
            'location': 'Blue Note Jazz Club',
            'category': 'music'
        },
        {
            'title': 'Food Festival',
            'description': 'Taste cuisines from around the world! Over 50 food vendors, live cooking demonstrations, and entertainment for the whole family.',
            'date': date.today() + timedelta(days=20),
            'time': datetime.strptime('11:00', '%H:%M').time(),
            'location': 'City Square',
            'category': 'food'
        },
        {
            'title': 'AI and Machine Learning Summit',
            'description': 'Explore the latest developments in artificial intelligence and machine learning. Expert speakers, hands-on demos, and career opportunities in AI.',
            'date': date.today() + timedelta(days=25),
            'time': datetime.strptime('10:00', '%H:%M').time(),
            'location': 'Tech Convention Center',
            'category': 'technology'
        },
        {
            'title': 'Business Networking Breakfast',
            'description': 'Start your day with meaningful connections. Meet local business owners, exchange ideas, and explore collaboration opportunities over breakfast.',
            'date': date.today() + timedelta(days=5),
            'time': datetime.strptime('07:30', '%H:%M').time(),
            'location': 'Grand Hotel Ballroom',
            'category': 'business'
        },
        {
            'title': 'Coding Bootcamp Info Session',
            'description': 'Learn about our intensive coding bootcamp program. Meet instructors, hear from alumni, and get your questions answered about transitioning to a tech career.',
            'date': date.today() + timedelta(days=8),
            'time': datetime.strptime('16:00', '%H:%M').time(),
            'location': 'Education Center',
            'category': 'education'
        },
        {
            'title': 'Charity Run for Education',
            'description': 'Join our annual charity run to support education initiatives in underserved communities. 5K and 10K options available. All fitness levels welcome!',
            'date': date.today() + timedelta(days=30),
            'time': datetime.strptime('08:00', '%H:%M').time(),
            'location': 'Riverside Park',
            'category': 'charity'
        },
        {
            'title': 'Photography Walk',
            'description': 'Explore the city through your lens! Guided photography walk covering architectural landmarks, street photography techniques, and composition tips.',
            'date': date.today() + timedelta(days=12),
            'time': datetime.strptime('15:00', '%H:%M').time(),
            'location': 'Historic District',
            'category': 'other'
        },
        {
            'title': 'Board Game Night',
            'description': 'Unwind with board games and new friends! We have everything from strategy games to party games. Bring your favorite game or learn something new.',
            'date': date.today() + timedelta(days=4),
            'time': datetime.strptime('19:00', '%H:%M').time(),
            'location': 'Community Center',
            'category': 'social'
        }
    ]
    
    created_events = []
    for i, event_data in enumerate(events_data):
        # Assign random user as organizer
        organizer = random.choice(users)
        
        # Check if event already exists
        existing_event = Event.query.filter_by(title=event_data['title']).first()
        if not existing_event:
            event = Event(
                user_id=organizer.id,
                title=event_data['title'],
                description=event_data['description'],
                date=event_data['date'],
                time=event_data['time'],
                location=event_data['location'],
                category=event_data['category'],
                image='default-event.jpg'
            )
            db.session.add(event)
            created_events.append(event)
            print(f"Created event: {event_data['title']} by {organizer.name}")
        else:
            created_events.append(existing_event)
            print(f"Event already exists: {event_data['title']}")
    
    db.session.commit()
    return created_events

def create_sample_rsvps(users, events):
    """Create sample RSVPs"""
    # Clear existing RSVPs
    RSVP.query.delete()
    db.session.commit()
    
    rsvp_count = 0
    for event in events:
        # Random number of attendees for each event (0-8)
        num_attendees = random.randint(0, min(8, len(users)))
        
        # Select random users (excluding the organizer)
        potential_attendees = [u for u in users if u.id != event.user_id]
        attendees = random.sample(potential_attendees, min(num_attendees, len(potential_attendees)))
        
        for attendee in attendees:
            rsvp = RSVP(
                user_id=attendee.id,
                event_id=event.id
            )
            db.session.add(rsvp)
            rsvp_count += 1
            print(f"RSVP: {attendee.name} -> {event.title}")
    
    db.session.commit()
    return rsvp_count

def main():
    """Main function to create sample data"""
    print("🎉 Creating sample data for EventHub...")
    
    with app.app_context():
        # Create tables if they don't exist
        db.create_all()
        
        # Create sample users
        print("\n📝 Creating sample users...")
        users = create_sample_users()
        
        # Create sample events
        print("\n📅 Creating sample events...")
        events = create_sample_events(users)
        
        # Create sample RSVPs
        print("\n✅ Creating sample RSVPs...")
        rsvp_count = create_sample_rsvps(users, events)
        
        print(f"\n🎊 Sample data creation complete!")
        print(f"   Users: {len(users)}")
        print(f"   Events: {len(events)}")
        print(f"   RSVPs: {rsvp_count}")
        
        print(f"\n🔑 Login credentials:")
        print(f"   Email: john@example.com")
        print(f"   Password: password123")
        print(f"\n   (All users have the same password: password123)")

if __name__ == '__main__':
    main()
