#!/usr/bin/env python3
"""
PythonAnywhere Deployment Helper for EventHub
This script helps generate deployment configurations and test setup
"""

import secrets
import os

def generate_secret_key():
    """Generate a secure secret key for production"""
    return secrets.token_hex(32)

def generate_deployment_config():
    """Generate deployment configuration file"""
    
    print("🚀 EventHub PythonAnywhere Deployment Helper")
    print("=" * 50)
    
    # Get user input
    username = input("Enter your PythonAnywhere username: ").strip()
    if not username:
        print("❌ Username is required!")
        return
    
    # Generate secret key
    secret_key = generate_secret_key()
    
    # Generate configuration
    config = f"""# EventHub PythonAnywhere Configuration
# Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

# ====== USER INFORMATION ======
PYTHONANYWHERE_USERNAME = "{username}"
PROJECT_DIRECTORY = "/home/{username}/eventhub"
WEB_APP_URL = f"http://{username}.pythonanywhere.com"

# ====== DATABASE CONFIGURATION ======
# Update these with your actual MySQL credentials from PythonAnywhere
DATABASE_USER = "{username}"
DATABASE_PASSWORD = "your_mysql_password_here"
DATABASE_NAME = f"{username}$eventhub"
DATABASE_HOST = f"{username}.mysql.pythonanywhere-services.com"
DATABASE_URL = f"mysql://{DATABASE_USER}:{DATABASE_PASSWORD}@{DATABASE_HOST}/{DATABASE_NAME}"

# ====== SECURITY ======
SECRET_KEY = "{secret_key}"

# ====== LOGGING ======
ERROR_LOG_PATH = f"/home/{username}/eventhub/error.log"

# ====== VIRTUAL ENVIRONMENT ======
VENV_PATH = f"/home/{username}/.virtualenvs/eventhub"

# ====== STATIC FILES ======
STATIC_URL = "/static/"
STATIC_DIRECTORY = f"/home/{username}/eventhub/static"

# ====== WSGI FILE ======
WSGI_FILE_PATH = f"/home/{username}/eventhub/wsgi.py"

print("✅ Configuration generated successfully!")
print(f"🔐 Secret Key: {secret_key}")
print(f"🌐 Your app will be available at: http://{username}.pythonanywhere.com")
print()
print("📋 Next Steps:")
print("1. Upload all files to your PythonAnywhere account")
print("2. Create virtual environment: mkvirtualenv --python=python3 eventhub")
print("3. Install dependencies: pip install -r requirements.txt")
print("4. Create MySQL database in PythonAnywhere dashboard")
print("5. Update wsgi.py with your database credentials")
print("6. Configure web app with above settings")
print("7. Reload web app and test!")
"""
    
    # Save configuration to file
    with open('deployment_config.py', 'w') as f:
        f.write(config)
    
    print(f"💾 Configuration saved to: deployment_config.py")
    
    # Generate wsgi.py content
    wsgi_content = f'''#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
WSGI configuration for EventHub Community Event Planner
PythonAnywhere deployment
"""

import os
import sys

# Add project directory to Python path
project_home = f'/home/{username}/eventhub'
if project_home not in sys.path:
    sys.path = [project_home] + sys.path

# Change to project directory
os.chdir(project_home)

# Import Flask app
from app import app as application

# Configure for production
application.config['DEBUG'] = False
application.config['TESTING'] = False

# Set up logging
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s %(message)s',
    handlers=[
        logging.FileHandler(f'/home/{username}/eventhub/error.log'),
        logging.StreamHandler()
    ]
)

# Database configuration
if not os.environ.get('DATABASE_URL'):
    os.environ['DATABASE_URL'] = 'mysql://{username}:yourpassword@{username}.mysql.pythonanywhere-services.com/{username}$eventhub'

# Security
if not os.environ.get('SECRET_KEY'):
    os.environ['SECRET_KEY'] = '{secret_key}'

# Initialize database
with application.app_context():
    from app import db
    try:
        db.create_all()
        print("✅ Database tables created successfully")
    except Exception as e:
        print(f"❌ Database creation error: {{e}}")

print("🚀 WSGI application loaded successfully")
'''
    
    with open('wsgi_production.py', 'w') as f:
        f.write(wsgi_content)
    
    print(f"💾 Production WSGI file saved to: wsgi_production.py")
    print()
    print("📝 Files Created:")
    print("   - deployment_config.py (contains all your settings)")
    print("   - wsgi_production.py (copy this to wsgi.py)")
    print()
    print("⚠️  IMPORTANT:")
    print("   1. Update database password in wsgi_production.py")
    print("   2. Copy wsgi_production.py content to your wsgi.py")
    print("   3. Keep your secret key and passwords secure!")

def test_local_setup():
    """Test local setup before deployment"""
    print("🧪 Testing local setup...")
    
    try:
        # Test imports
        from app import app, db
        print("✅ Flask app imports successfully")
        
        # Test database
        with app.app_context():
            from app import User, Event, RSVP
            print("✅ Database models import successfully")
            
        # Test configuration
        print(f"✅ Upload folder: {app.config.get('UPLOAD_FOLDER')}")
        print(f"✅ Database URL configured: {'✅' if app.config.get('SQLALCHEMY_DATABASE_URI') else '❌'}")
        print(f"✅ Secret key configured: {'✅' if app.config.get('SECRET_KEY') else '❌'}")
        
        print("🎉 Local setup test passed! Ready for deployment.")
        
    except Exception as e:
        print(f"❌ Local setup test failed: {e}")
        print("Please fix issues before deploying to PythonAnywhere.")

if __name__ == '__main__':
    from datetime import datetime
    
    print("🚀 EventHub PythonAnywhere Deployment Helper")
    print("=" * 50)
    print("1. Generate deployment configuration")
    print("2. Test local setup")
    print("3. Exit")
    
    choice = input("Choose an option (1-3): ").strip()
    
    if choice == '1':
        generate_deployment_config()
    elif choice == '2':
        test_local_setup()
    elif choice == '3':
        print("👋 Goodbye!")
    else:
        print("❌ Invalid choice!")
