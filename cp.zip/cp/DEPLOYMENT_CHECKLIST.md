# 🚀 PythonAnywhere Deployment Checklist

Use this checklist to ensure successful deployment of EventHub Community Event Planner.

## 📋 Pre-Deployment Checklist

### Local Setup ✅
- [ ] Application runs locally without errors
- [ ] All dependencies installed (`pip install -r requirements.txt`)
- [ ] Database creates successfully (`python create_sample_data.py`)
- [ ] Static files load correctly
- [ ] No import errors or missing modules

### Account Setup ✅
- [ ] PythonAnywhere account created
- [ ] Web app created (Flask framework)
- [ ] MySQL database created
- [ ] Database credentials noted

## 📁 Files Upload

### Required Files ✅
- [ ] `app.py` - Main Flask application
- [ ] `routes.py` - Application routes
- [ ] `config.py` - Configuration settings
- [ ] `wsgi.py` - WSGI configuration
- [ ] `requirements.txt` - Python dependencies
- [ ] `create_sample_data.py` - Sample data (optional)

### Static Files ✅
- [ ] `static/css/style.css` - Custom styles
- [ ] `static/js/main.js` - JavaScript functionality
- [ ] `static/images/` - Image assets
- [ ] `static/images/uploads/` - Upload directory (with .gitkeep)

### Templates ✅
- [ ] `templates/base.html` - Base template
- [ ] `templates/index.html` - Homepage
- [ ] `templates/auth/` - Authentication templates
- [ ] `templates/events/` - Event management templates
- [ ] `templates/profile.html` - User profile
- [ ] `templates/errors/` - Error page templates

## ⚙️ PythonAnywhere Configuration

### Virtual Environment ✅
- [ ] Virtual environment created: `mkvirtualenv --python=python3 eventhub`
- [ ] Dependencies installed: `pip install -r requirements.txt`
- [ ] Flask version verified: `python -c "import flask; print(flask.__version__)"`

### Web App Settings ✅
- [ ] Virtual environment path set: `/home/username/.virtualenvs/eventhub`
- [ ] Working directory set: `/home/username/eventhub`
- [ ] WSGI file path set: `/home/username/eventhub/wsgi.py`
- [ ] Python version selected: Python 3.11

### Static Files Mapping ✅
- [ ] URL: `/static/` → Directory: `/home/username/eventhub/static/`
- [ ] Permissions set: `chmod -R 755 ~/eventhub/static/`

### Environment Variables ✅
- [ ] `FLASK_CONFIG`: `pythonanywhere`
- [ ] `SECRET_KEY`: Generated secure key
- [ ] `DATABASE_URL`: MySQL connection string

## 🗄️ Database Setup

### SQLite Database (Free Accounts - Recommended) ✅
- [ ] No database creation required (automatic)
- [ ] Database file path: `/home/username/eventhub/event_planner.db`
- [ ] Write permissions for database directory
- [ ] SQLite works with PythonAnywhere free accounts

### MySQL Database (Paid Accounts Only) ✅
- [ ] Database created in PythonAnywhere dashboard
- [ ] Connection string updated in wsgi.py
- [ ] Database URL format correct
- [ ] Credentials secure and not hardcoded

### Database Testing ✅
- [ ] Connection test successful
- [ ] Tables created without errors
- [ ] Sample data populated (optional)
- [ ] Database file created automatically

## 🔧 WSGI Configuration

### File Updates ✅
- [ ] Username updated in all paths (`yourusername` → actual username)
- [ ] Database credentials updated
- [ ] Secret key generated and updated
- [ ] Error log path correct

### WSGI File Permissions ✅
- [ ] File is executable: `chmod +x wsgi.py`
- [ ] File location correct: `/home/username/eventhub/wsgi.py`
- [ ] No syntax errors: `python -m py_compile wsgi.py`

## 🚀 Deployment Steps

### Final Configuration ✅
- [ ] All settings updated in PythonAnywhere dashboard
- [ ] Web app reloaded (green reload button)
- [ ] No error messages in reload log
- [ ] Application status: "Running"

### URL Testing ✅
- [ ] Homepage loads: `http://username.pythonanywhere.com`
- [ ] Static files load (CSS, JS, images)
- [ ] Registration page works
- [ ] Login functionality works
- [ ] Event creation works
- [ ] RSVP functionality works

## 🔍 Post-Deployment Testing

### Core Features ✅
- [ ] User registration and login
- [ ] Event creation, editing, deletion
- [ ] RSVP system functionality
- [ ] Search and filter features
- [ ] Profile page display
- [ ] Responsive design on mobile

### Error Handling ✅
- [ ] 404 error page displays correctly
- [ ] 403 error page displays correctly
- [ ] 500 error page displays correctly
- [ ] Form validation messages show
- [ ] Toast notifications work

### Performance ✅
- [ ] Page load times acceptable (<3 seconds)
- [ ] Images load properly
- [ ] No broken links
- [ ] Mobile performance acceptable

## 🔧 Troubleshooting Guide

### Common Issues and Solutions

#### 502 Bad Gateway
**Symptoms**: Page doesn't load, server error
**Causes**: 
- WSGI file syntax error
- Database connection issue
- Virtual environment not activated
**Solutions**:
```bash
# Check error logs
tail -f ~/eventhub/error.log

# Check WSGI syntax
python -m py_compile wsgi.py

# Test database connection
python -c "
import os
from sqlalchemy import create_engine
engine = create_engine(os.environ.get('DATABASE_URL'))
engine.connect()
"
```

#### 404 Not Found
**Symptoms**: Pages return 404 errors
**Causes**:
- Static files not mapped
- URL routing issues
- File permissions
**Solutions**:
```bash
# Check static files mapping
ls -la ~/eventhub/static/

# Check file permissions
chmod -R 755 ~/eventhub/

# Restart web app
# Click reload button in dashboard
```

#### 500 Internal Server Error
**Symptoms**: Server crashes on specific pages
**Causes**:
- Import errors
- Database query errors
- Missing environment variables
**Solutions**:
```bash
# Check application logs
tail -f ~/eventhub/error.log

# Test imports manually
python -c "
from app import app, db
from routes import *
print('All imports successful')
"
```

#### Database Connection Errors
**Symptoms**: Database-related errors
**Causes**:
- Wrong credentials
- Database not running
- Connection string format
**Solutions**:
```bash
# Verify database exists
# Check in PythonAnywhere Databases tab

# Test connection manually
mysql -u username -p -h username.mysql.pythonanywhere-services.com username$eventhub

# Check connection string format
echo $DATABASE_URL
```

## 📊 Monitoring and Maintenance

### Regular Tasks ✅
- [ ] Check error logs weekly
- [ ] Update dependencies monthly
- [ ] Backup database regularly
- [ ] Monitor performance metrics
- [ ] Update security patches

### Backup Strategy ✅
- [ ] Database backups automated
- [ ] File backups in version control
- [ ] Configuration backups
- [ ] Recovery plan documented

## 🎯 Go-Live Checklist

Before promoting your site:

### Security ✅
- [ ] Secret key is secure and unique
- [ ] Database credentials are strong
- [ ] Debug mode disabled
- [ ] Error logs don't expose sensitive info
- [ ] HTTPS enabled (paid plans)

### Performance ✅
- [ ] Images optimized for web
- [ ] CSS and JS minified (optional)
- [ ] Caching configured (optional)
- [ ] CDN configured (optional)

### Content ✅
- [ ] Sample data removed or replaced
- [ ] Default content updated
- [ ] Contact information current
- [ ] Privacy policy added (optional)
- [ ] Terms of service added (optional)

## 🎉 Success Metrics

Your deployment is successful when:

- ✅ Homepage loads without errors
- ✅ All navigation links work
- ✅ User authentication functions
- ✅ Event management works
- ✅ RSVP system operates
- ✅ Search features work
- ✅ Mobile responsive design
- ✅ Error pages display correctly
- ✅ No console errors
- ✅ Performance acceptable

## 📞 Support Resources

If you need help:

1. **PythonAnywhere Docs**: [docs.pythonanywhere.com](https://docs.pythonanywhere.com/)
2. **Flask Documentation**: [flask.palletsprojects.com](https://flask.palletsprojects.com/)
3. **SQLAlchemy Docs**: [docs.sqlalchemy.org](https://docs.sqlalchemy.org/)
4. **Community Forums**: [pythonanywhere.com/forums](https://www.pythonanywhere.com/forums/)

---

## 🚀 Ready to Launch!

Once you've completed this checklist, your EventHub Community Event Planner will be fully functional and ready for users! 🎊

**Your Live URL**: `http://yourusername.pythonanywhere.com`

Congratulations on deploying your modern, professional event planning platform! 🎉
