from flask import render_template, request, redirect, url_for, flash, session, jsonify, abort
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import os
from app import app, db, User, Event, RSVP, login_required, format_datetime
import re

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Home Route
@app.route('/')
def index():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    filter_type = request.args.get('filter', 'upcoming')
    
    # Build query
    query = Event.query
    
    # Search filter
    if search:
        query = query.filter(
            (Event.title.contains(search)) | 
            (Event.location.contains(search)) |
            (Event.description.contains(search))
        )
    
    # Category filter
    if category:
        query = query.filter(Event.category == category)
    
    # Date filter
    today = date.today()
    if filter_type == 'upcoming':
        query = query.filter(Event.date >= today)
    elif filter_type == 'past':
        query = query.filter(Event.date < today)
    
    # Order by date
    query = query.order_by(Event.date.asc(), Event.time.asc())
    
    # Paginate
    events = query.paginate(page=page, per_page=12, error_out=False)
    
    # Get all categories for filter dropdown
    categories = db.session.query(Event.category).distinct().all()
    categories = [cat[0] for cat in categories]
    
    # Fallback categories if no events exist
    if not categories:
        categories = ['conference', 'workshop', 'meetup', 'social', 'sports', 'music', 'food', 'technology', 'business', 'education', 'charity']
    
    # Check RSVP status for logged-in users
    user_rsvps = {}
    if 'user_id' in session:
        user_rsvps = {rsvp.event_id: True for rsvp in RSVP.query.filter_by(user_id=session['user_id']).all()}
    
    return render_template('index.html', 
                         events=events, 
                         categories=categories,
                         user_rsvps=user_rsvps,
                         search=search,
                         selected_category=category,
                         filter_type=filter_type)

# Authentication Routes
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        # Validation
        errors = []
        
        if not name or len(name) < 2:
            errors.append('Name must be at least 2 characters long')
        
        if not email or not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
            errors.append('Please enter a valid email address')
        
        if not password or len(password) < 6:
            errors.append('Password must be at least 6 characters long')
        
        if password != confirm_password:
            errors.append('Passwords do not match')
        
        # Check if user already exists
        if User.query.filter_by(email=email).first():
            errors.append('Email already registered')
        
        if errors:
            for error in errors:
                flash(error, 'danger')
            return render_template('auth/register.html')
        
        # Create new user
        hashed_password = generate_password_hash(password)
        new_user = User(name=name, email=email, password=hashed_password)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('Registration failed. Please try again.', 'danger')
            return render_template('auth/register.html')
    
    return render_template('auth/register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['user_name'] = user.name
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('auth/login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully', 'info')
    return redirect(url_for('index'))

# Profile Route
@app.route('/profile')
@login_required
def profile():
    user = User.query.get(session['user_id'])
    user_events = Event.query.filter_by(user_id=user.id).order_by(Event.created_at.desc()).limit(5).all()
    user_rsvps = RSVP.query.filter_by(user_id=user.id).order_by(RSVP.created_at.desc()).limit(5).all()
    
    return render_template('profile.html', user=user, user_events=user_events, user_rsvps=user_rsvps)

# Event Routes
@app.route('/events/create', methods=['GET', 'POST'])
@login_required
def create_event():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        event_date = request.form.get('date', '')
        event_time = request.form.get('time', '')
        location = request.form.get('location', '').strip()
        category = request.form.get('category', '').strip()
        
        # Validation
        errors = []
        
        if not title:
            errors.append('Event title is required')
        
        if not description:
            errors.append('Event description is required')
        
        if not event_date:
            errors.append('Event date is required')
        else:
            try:
                event_date_obj = datetime.strptime(event_date, '%Y-%m-%d').date()
                if event_date_obj < date.today():
                    errors.append('Event date cannot be in the past')
            except ValueError:
                errors.append('Invalid date format')
        
        if not event_time:
            errors.append('Event time is required')
        
        if not location:
            errors.append('Event location is required')
        
        if not category:
            errors.append('Event category is required')
        
        if errors:
            for error in errors:
                flash(error, 'danger')
            return render_template('events/create.html')
        
        # Handle image upload
        image_filename = 'default-event.svg'
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Add timestamp to avoid conflicts
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                image_filename = f"{timestamp}_{filename}"
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                file.save(file_path)
        
        # Create event
        try:
            event_date_obj = datetime.strptime(event_date, '%Y-%m-%d').date()
            event_time_obj = datetime.strptime(event_time, '%H:%M').time()
            
            new_event = Event(
                user_id=session['user_id'],
                title=title,
                description=description,
                date=event_date_obj,
                time=event_time_obj,
                location=location,
                category=category,
                image=image_filename
            )
            
            db.session.add(new_event)
            db.session.commit()
            flash('Event created successfully!', 'success')
            return redirect(url_for('event_detail', id=new_event.id))
            
        except Exception as e:
            db.session.rollback()
            flash('Failed to create event. Please try again.', 'danger')
            return render_template('events/create.html')
    
    return render_template('events/create.html')

@app.route('/events/<int:id>')
def event_detail(id):
    event = Event.query.get_or_404(id)
    organizer = User.query.get(event.user_id)
    
    # Get RSVPs
    rsvps = RSVP.query.filter_by(event_id=id).join(User).order_by(RSVP.created_at.asc()).all()
    attendee_count = len(rsvps)
    
    # Check if current user is attending
    is_attending = False
    if 'user_id' in session:
        is_attending = RSVP.query.filter_by(user_id=session['user_id'], event_id=id).first() is not None
    
    # Check if user is the organizer
    is_organizer = 'user_id' in session and session['user_id'] == event.user_id
    
    return render_template('events/detail.html', 
                         event=event, 
                         organizer=organizer,
                         rsvps=rsvps,
                         attendee_count=attendee_count,
                         is_attending=is_attending,
                         is_organizer=is_organizer,
                         format_datetime=format_datetime)

@app.route('/events/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_event(id):
    event = Event.query.get_or_404(id)
    
    # Check if user is the organizer
    if event.user_id != session['user_id']:
        flash('You can only edit your own events', 'danger')
        return redirect(url_for('event_detail', id=id))
    
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        event_date = request.form.get('date', '')
        event_time = request.form.get('time', '')
        location = request.form.get('location', '').strip()
        category = request.form.get('category', '').strip()
        
        # Validation
        errors = []
        
        if not title:
            errors.append('Event title is required')
        
        if not description:
            errors.append('Event description is required')
        
        if not event_date:
            errors.append('Event date is required')
        else:
            try:
                event_date_obj = datetime.strptime(event_date, '%Y-%m-%d').date()
                if event_date_obj < date.today():
                    errors.append('Event date cannot be in the past')
            except ValueError:
                errors.append('Invalid date format')
        
        if not event_time:
            errors.append('Event time is required')
        
        if not location:
            errors.append('Event location is required')
        
        if not category:
            errors.append('Event category is required')
        
        if errors:
            for error in errors:
                flash(error, 'danger')
            return render_template('events/edit.html', event=event)
        
        # Handle image upload
        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Add timestamp to avoid conflicts
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                image_filename = f"{timestamp}_{filename}"
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                file.save(file_path)
                event.image = image_filename
        
        # Update event
        try:
            event_date_obj = datetime.strptime(event_date, '%Y-%m-%d').date()
            event_time_obj = datetime.strptime(event_time, '%H:%M').time()
            
            event.title = title
            event.description = description
            event.date = event_date_obj
            event.time = event_time_obj
            event.location = location
            event.category = category
            
            db.session.commit()
            flash('Event updated successfully!', 'success')
            return redirect(url_for('event_detail', id=event.id))
            
        except Exception as e:
            db.session.rollback()
            flash('Failed to update event. Please try again.', 'danger')
            return render_template('events/edit.html', event=event)
    
    return render_template('events/edit.html', event=event)

@app.route('/events/<int:id>/delete', methods=['POST'])
@login_required
def delete_event(id):
    event = Event.query.get_or_404(id)
    
    # Check if user is the organizer
    if event.user_id != session['user_id']:
        flash('You can only delete your own events', 'danger')
        return redirect(url_for('event_detail', id=id))
    
    try:
        db.session.delete(event)
        db.session.commit()
        flash('Event deleted successfully!', 'success')
        return redirect(url_for('my_events'))
    except Exception as e:
        db.session.rollback()
        flash('Failed to delete event. Please try again.', 'danger')
        return redirect(url_for('event_detail', id=id))

@app.route('/my-events')
@login_required
def my_events():
    page = request.args.get('page', 1, type=int)
    events = Event.query.filter_by(user_id=session['user_id']).order_by(Event.created_at.desc()).paginate(
        page=page, per_page=10, error_out=False
    )
    
    return render_template('events/my_events.html', events=events)

# RSVP Routes
@app.route('/events/<int:id>/rsvp', methods=['POST'])
@login_required
def rsvp_event(id):
    event = Event.query.get_or_404(id)
    
    # Check if user is the organizer
    if event.user_id == session['user_id']:
        flash('You cannot RSVP to your own event', 'warning')
        return redirect(url_for('event_detail', id=id))
    
    # Check if already RSVP'd
    existing_rsvp = RSVP.query.filter_by(user_id=session['user_id'], event_id=id).first()
    if existing_rsvp:
        flash('You have already RSVP\'d to this event', 'info')
        return redirect(url_for('event_detail', id=id))
    
    # Create RSVP
    try:
        new_rsvp = RSVP(user_id=session['user_id'], event_id=id)
        db.session.add(new_rsvp)
        db.session.commit()
        flash('You are now attending this event!', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Failed to RSVP. Please try again.', 'danger')
    
    return redirect(url_for('event_detail', id=id))

@app.route('/events/<int:id>/cancel-rsvp', methods=['POST'])
@login_required
def cancel_rsvp(id):
    event = Event.query.get_or_404(id)
    
    # Find and delete RSVP
    rsvp = RSVP.query.filter_by(user_id=session['user_id'], event_id=id).first()
    if rsvp:
        try:
            db.session.delete(rsvp)
            db.session.commit()
            flash('Your RSVP has been cancelled', 'info')
        except Exception as e:
            db.session.rollback()
            flash('Failed to cancel RSVP. Please try again.', 'danger')
    else:
        flash('You are not attending this event', 'warning')
    
    return redirect(url_for('event_detail', id=id))

# AJAX Routes
@app.route('/api/search-events')
def search_events():
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    filter_type = request.args.get('filter', 'upcoming')
    
    # Build query
    query = Event.query
    
    # Search filter
    if search:
        query = query.filter(
            (Event.title.contains(search)) | 
            (Event.location.contains(search))
        )
    
    # Category filter
    if category:
        query = query.filter(Event.category == category)
    
    # Date filter
    today = date.today()
    if filter_type == 'upcoming':
        query = query.filter(Event.date >= today)
    elif filter_type == 'past':
        query = query.filter(Event.date < today)
    
    # Order and limit
    events = query.order_by(Event.date.asc(), Event.time.asc()).limit(20).all()
    
    # Format response
    event_data = []
    for event in events:
        event_data.append({
            'id': event.id,
            'title': event.title,
            'date': event.date.strftime('%Y-%m-%d'),
            'time': event.time.strftime('%I:%M %p'),
            'location': event.location,
            'category': event.category,
            'image': event.image,
            'organizer': event.organizer.name
        })
    
    return jsonify({'events': event_data})

# Error Handlers
@app.errorhandler(404)
def not_found_error(error):
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('errors/500.html'), 500

@app.errorhandler(403)
def forbidden_error(error):
    return render_template('errors/403.html'), 403
