# 🗄️ SQLite Deployment Guide (Free PythonAnywhere)

Perfect for PythonAnywhere **free accounts** - no MySQL required!

## 🚀 Why SQLite is Perfect for Free Accounts

### ✅ **Advantages**
- **No setup required** - database file created automatically
- **Works on free accounts** - no paid features needed
- **Easy backups** - just copy the `.db` file
- **Fast performance** - perfect for small to medium apps
- **Reliable** - no external dependencies

### 📁 **Database Location**
```
/home/yourusername/eventhub/event_planner.db
```

## 📋 **Simplified Deployment Steps**

### **Step 1: Upload Files**
1. Create `eventhub` folder in PythonAnywhere "Files" tab
2. Upload all your project files into `eventhub` folder
3. Verify structure matches the guide

### **Step 2: Setup Virtual Environment**
```bash
# In PythonAnywhere Bash console
mkvirtualenv --python=python3 eventhub
workon eventhub
pip install -r requirements.txt
```

### **Step 3: Configure Web App**
1. Go to "Web" tab → Your web app
2. Set **Virtual environment**: `/home/yourusername/.virtualenvs/eventhub`
3. Set **Working directory**: `/home/yourusername/eventhub`
4. Set **WSGI file**: `/home/yourusername/eventhub/wsgi.py`

### **Step 4: Set Static Files**
1. In "Web" tab → "Static files" section
2. Add: **URL** `/static/` → **Directory** `/home/yourusername/eventhub/static/`

### **Step 5: Add Environment Variables**
1. In "Web" tab → "Variables" section
2. Add: `FLASK_CONFIG` = `pythonanywhere`
3. Add: `SECRET_KEY` = `your-secure-secret-key-here`

### **Step 6: Reload and Test**
1. Click the **green reload button** next to your web app
2. Visit: `http://yourusername.pythonanywhere.com`
3. Test all features

## 🔧 **Minimal WSGI Configuration**

Your `wsgi.py` is already configured for SQLite! Just update your username:

```python
# ====== UPDATE THIS: Replace 'yourusername' with your PythonAnywhere username ======
YOUR_USERNAME = 'yourusername'
```

That's it! No database configuration needed.

## 🎯 **What Happens Automatically**

### Database Creation
- SQLite file created on first run
- Tables created automatically
- No manual setup required

### Configuration
- Development config loaded automatically
- SQLite database path set automatically
- Error logging configured automatically

## 🧪 **Testing Your Deployment**

### Quick Test Commands
```bash
# Test Flask import
python -c "import flask; print('✅ Flask working')"

# Test database
python create_sample_data.py

# Check database file
ls -la ~/eventhub/event_planner.db
```

### Manual Testing
1. **Homepage**: Visit your URL
2. **Registration**: Create a new account
3. **Login**: Test authentication
4. **Event Creation**: Create a test event
5. **RSVP**: Test RSVP functionality

## 📊 **Database Management**

### Backup Your Database
```bash
# Copy database file (backup)
cp ~/eventhub/event_planner.db ~/eventhub/backup_$(date +%Y%m%d).db

# Download database file
# Use PythonAnywhere Files tab to download event_planner.db
```

### Reset Database
```bash
# Delete and recreate (fresh start)
rm ~/eventhub/event_planner.db
python create_sample_data.py
```

## 🔍 **Troubleshooting SQLite Issues**

### Database Permission Errors
**Problem**: Can't create database file
**Solution**:
```bash
# Check directory permissions
ls -la ~/eventhub/
chmod 755 ~/eventhub/
```

### Database Locked Errors
**Problem**: Database is locked
**Solution**:
```bash
# Check if Flask is running
ps aux | grep python

# Restart web app
# Click reload button in PythonAnywhere dashboard
```

### Import Errors
**Problem**: Module not found
**Solution**:
```bash
# Check virtual environment
which python
pip list | grep flask

# Reinstall dependencies
pip install -r requirements.txt
```

## 🚀 **Going Live with SQLite**

### Final Checklist
- [ ] All files uploaded to `eventhub` folder
- [ ] Virtual environment created and packages installed
- [ ] Web app configured with correct paths
- [ ] Static files mapped correctly
- [ ] Environment variables set
- [ ] Web app reloaded
- [ ] Database created automatically
- [ ] All features tested

### Success Indicators
✅ **Homepage loads** without errors
✅ **Registration works** 
✅ **Login successful**
✅ **Event creation works**
✅ **Database operations work**
✅ **No console errors**

## 🎉 **You're Live!**

Your EventHub Community Event Planner is now running on PythonAnywhere with SQLite!

**Your URL**: `http://yourusername.pythonanywhere.com`

**Features Available**:
- ✅ User authentication
- ✅ Event management
- ✅ RSVP system
- ✅ Search and filter
- ✅ Modern UI
- ✅ Mobile responsive
- ✅ Error handling

## 📞 **SQLite Benefits**

- **Zero maintenance** - no database server to manage
- **Instant backups** - just copy one file
- **Perfect reliability** - no connection issues
- **Fast performance** - local file access
- **Free forever** - no database costs

## 🔧 **Future Upgrades**

When you're ready to upgrade to a paid PythonAnywhere account:

1. **Export data** from SQLite
2. **Create MySQL database** in PythonAnywhere
3. **Update wsgi.py** with MySQL configuration
4. **Import data** to MySQL
5. **Test and reload**

---

**Perfect for getting started with EventHub on PythonAnywhere free account!** 🗄️🚀
