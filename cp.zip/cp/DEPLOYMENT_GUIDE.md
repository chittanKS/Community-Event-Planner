# PythonAnywhere Deployment Guide for EventHub

This step-by-step guide will help you deploy your EventHub Community Event Planner on PythonAnywhere.

## 🚀 Step 1: PythonAnywhere Setup

### 1.1 Create Account
1. Sign up at [pythonanywhere.com](https://www.pythonanywhere.com)
2. Choose a free "Beginner" account or paid plan for better performance

### 1.2 Create Web App
1. Go to "Web" tab → "Add a new web app"
2. Select "Flask" framework
3. Choose "Python 3.11" (or latest 3.x)
4. Click next and create the web app

## 📁 Step 2: Upload Files

### 2.1 Create Project Directory
```bash
# In PythonAnywhere Bash console
mkdir ~/eventhub
cd ~/eventhub
```

### 2.2 Upload Your Files
**Option A: Git Clone (Recommended)**
```bash
# If you have a Git repository
git clone <your-repo-url> ~/eventhub
```

**Option B: Manual Upload**
1. Go to "Files" tab in your PythonAnywhere dashboard
2. Navigate to your home directory (where you see folders like `Downloads`, `Documents`, etc.)
3. **Create the `eventhub` directory**:
   - Click "New directory" or "Create folder"
   - Name it exactly: `eventhub`
   - Click "Create"
4. **Enter the `eventhub` directory** by clicking on it
5. **Upload all project files** into the `eventhub` directory:
   - Click "Upload files"
   - Select all files from your local `cp` folder
   - Upload them so they're inside `/home/yourusername/eventhub/`
6. **Verify the structure** - it should look like:
```
/home/yourusername/eventhub/
├── app.py
├── routes.py
├── config.py
├── wsgi.py
├── requirements.txt
├── create_sample_data.py
├── static/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── images/
│       └── uploads/
│           └── .gitkeep
└── templates/
    ├── base.html
    ├── index.html
    ├── auth/
    │   ├── login.html
    │   └── register.html
    ├── events/
    │   ├── create.html
    │   ├── detail.html
    │   ├── edit.html
    │   └── my_events.html
    ├── profile.html
    └── errors/
        ├── 404.html
        ├── 403.html
        └── 500.html
```

**Important**: Make sure all files are uploaded **inside** the `eventhub` folder, not in your home directory.

## 🐍 Step 3: Set Up Virtual Environment

### 3.1 Create Virtual Environment
```bash
# In PythonAnywhere Bash console
mkvirtualenv --python=python3 eventhub
```

### 3.2 Install Dependencies
```bash
# Activate virtual environment
workon eventhub

# Install requirements
pip install -r ~/eventhub/requirements.txt
```

### 3.3 Verify Installation
```bash
# Test Flask installation
python -c "import flask; print('Flask version:', flask.__version__)"
```

## 🗄️ Step 4: Database Setup

### 4.1 SQLite Database (Free PythonAnywhere - Recommended)
**No MySQL required!** SQLite works perfectly on PythonAnywhere free accounts.

1. **No database creation needed** - SQLite file will be created automatically
2. **Database file location**: `/home/yourusername/eventhub/event_planner.db`
3. **Advantages**:
   - No additional setup required
   - Works on free PythonAnywhere accounts
   - Automatic file creation
   - Easy backups

### 4.2 MySQL Database (Paid Accounts Only)
If you have a paid PythonAnywhere account and prefer MySQL:

1. Go to "Databases" tab
2. Click "MySQL" → "Create a new database"
3. Choose a password and note the connection details

### 4.3 Database Connection String

**SQLite (Recommended for Free Accounts)**:
```python
# This will be set automatically
sqlite:///home/yourusername/eventhub/event_planner.db
```

**MySQL (Paid Accounts Only)**:
```python
# Format: mysql://username:password@username.mysql.pythonanywhere-services.com/username$eventhub
mysql://yourusername:yourpassword@yourusername.mysql.pythonanywhere-services.com/yourusername$eventhub
```

### 4.3 Update Configuration
Edit `~/eventhub/wsgi.py` and update these lines:

```python
# Update this path
project_home = u'/home/yourusername/eventhub'

# Update this path for error log
file_handler = FileHandler('/home/yourusername/eventhub/error.log')

# Update database URL
os.environ['DATABASE_URL'] = 'mysql://yourusername:yourpassword@yourusername.mysql.pythonanywhere-services.com/yourusername$eventhub'

# Update secret key
os.environ['SECRET_KEY'] = 'your-secure-secret-key-here'
```

## ⚙️ Step 5: Configure Web App

### 5.1 Set Virtual Environment
1. Go to "Web" tab → Click on your web app
2. Set "Virtual environment" to: `/home/yourusername/.virtualenvs/eventhub`
3. Set "Working directory" to: `/home/yourusername/eventhub`
4. Set "WSGI file" to: `/home/yourusername/eventhub/wsgi.py`

### 5.2 Static Files Configuration
1. In "Web" tab → "Static files" section
2. Add URL: `/static/` → Directory: `/home/yourusername/eventhub/static/`

### 5.3 Environment Variables
1. In "Web" tab → "Variables" section
2. Add these variables:
   - `FLASK_CONFIG`: `pythonanywhere`
   - `SECRET_KEY`: `your-secure-secret-key-here`
   - `DATABASE_URL`: `your-mysql-connection-string`

## 🔧 Step 6: Update WSGI Configuration

### 6.1 Edit wsgi.py
Make sure your `wsgi.py` looks like this:

```python
#!/usr/bin/env python3
import os
import sys

# Add project directory to Python path
project_home = u'/home/yourusername/eventhub'
if project_home not in sys.path:
    sys.path = [project_home] + sys.path

# Change to project directory
os.chdir(project_home)

# Import Flask app
from app import app as application

# Configure for production
application.config['DEBUG'] = False
application.config['TESTING'] = False

# Set up logging
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s %(message)s',
    handlers=[
        logging.FileHandler('/home/yourusername/eventhub/error.log'),
        logging.StreamHandler()
    ]
)

# Set up database URI
if not os.environ.get('DATABASE_URL'):
    os.environ['DATABASE_URL'] = 'mysql://yourusername:yourpassword@yourusername.mysql.pythonanywhere-services.com/yourusername$eventhub'

# Set secret key
if not os.environ.get('SECRET_KEY'):
    os.environ['SECRET_KEY'] = 'your-production-secret-key-here'

# Initialize database
with application.app_context():
    from app import db
    try:
        db.create_all()
        print("Database tables created successfully")
    except Exception as e:
        print(f"Database creation error: {e}")

print("WSGI application loaded successfully")
```

## 🚀 Step 7: Initialize Database

### 7.1 Create Database Tables
```bash
# In PythonAnywhere Bash console
workon eventhub
cd ~/eventhub
python create_sample_data.py
```

### 7.2 Verify Database
```bash
# Check if tables were created
python -c "
from app import app, db
with app.app_context():
    from app import User, Event
    print('Users:', User.query.count())
    print('Events:', Event.query.count())
"
```

## 🔄 Step 8: Reload and Test

### 8.1 Reload Web App
1. Go to "Web" tab
2. Click the green "Reload" button next to your web app
3. Wait for reload to complete

### 8.2 Test Your Application
1. Visit your app URL: `http://yourusername.pythonanywhere.com`
2. Test all features:
   - Homepage loads
   - Registration works
   - Login works
   - Event creation works
   - RSVP works

## 🔍 Step 9: Troubleshooting

### Common Issues and Solutions

#### 9.1 502 Bad Gateway Error
**Problem**: Web app not responding
**Solution**:
```bash
# Check error log
tail -f ~/eventhub/error.log

# Check if Flask is running
ps aux | grep python
```

#### 9.2 Database Connection Error
**Problem**: Can't connect to MySQL
**Solution**:
1. Verify database credentials in wsgi.py
2. Check database is running in "Databases" tab
3. Test connection manually:
```bash
python -c "
import os
from sqlalchemy import create_engine
engine = create_engine(os.environ.get('DATABASE_URL'))
engine.connect()
print('Database connection successful')
"
```

#### 9.3 Static Files Not Loading
**Problem**: CSS/JS files not found
**Solution**:
1. Check static files mapping in "Web" tab
2. Verify file permissions:
```bash
chmod -R 755 ~/eventhub/static/
```

#### 9.4 Import Errors
**Problem**: Module not found errors
**Solution**:
```bash
# Check virtual environment
workon eventhub
pip list | grep flask

# Reinstall if needed
pip install -r requirements.txt
```

#### 9.5 Permission Errors
**Problem**: Permission denied errors
**Solution**:
```bash
# Fix file permissions
chmod +x ~/eventhub/wsgi.py
chmod -R 755 ~/eventhub/
```

## 📊 Step 10: Monitor and Maintain

### 10.1 Check Logs Regularly
```bash
# Application logs
tail -f ~/eventhub/error.log

# Web server logs
tail -f /var/log/apache2/error.log
```

### 10.2 Update Dependencies
```bash
# Regularly update packages
workon eventhub
pip install --upgrade -r requirements.txt
```

### 10.3 Backup Database
```bash
# Export database backup
mysqldump -u yourusername -p yourusername$eventhub > backup.sql
```

## 🎯 Final Checklist

Before going live, ensure:

- [ ] All files uploaded correctly
- [ ] Virtual environment created and packages installed
- [ ] Database created and configured
- [ ] WSGI file updated with correct paths
- [ ] Static files mapped correctly
- [ ] Environment variables set
- [ ] Web app reloaded successfully
- [ ] All features tested
- [ ] Error logs checked
- [ ] SSL certificate enabled (for paid plans)

## 🚀 Going Live

Once everything is working:

1. **Custom Domain** (optional): Configure custom domain in "Web" tab
2. **SSL Certificate**: Enable HTTPS (included in paid plans)
3. **Monitor Performance**: Use PythonAnywhere monitoring tools
4. **Regular Backups**: Set up automated database backups

## 📞 Support

If you encounter issues:

1. **PythonAnywhere Docs**: [docs.pythonanywhere.com](https://docs.pythonanywhere.com/)
2. **Community Forum**: [pythonanywhere.com/forums](https://www.pythonanywhere.com/forums/)
3. **Support Tickets**: Submit ticket through PythonAnywhere dashboard

## 🎉 Success!

Your EventHub Community Event Planner is now live on PythonAnywhere! 🎊

**Your URL**: `http://yourusername.pythonanywhere.com`

Users can now:
- Browse and discover events
- Register and login
- Create and manage events
- RSVP to events
- Search and filter events
- Connect with the community

Congratulations on deploying your modern, professional event planning platform! 🚀
