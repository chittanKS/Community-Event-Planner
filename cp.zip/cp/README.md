# EventHub - Community Event Planner

A modern, full-stack community event planning platform built with Flask, featuring a beautiful glassmorphism UI and comprehensive event management capabilities.

## 🌟 Features

### 🎨 Modern UI/UX
- **Glassmorphism Design**: Modern card-based layout with blur effects
- **Responsive Design**: Mobile-first approach with Bootstrap 5
- **Smooth Animations**: Hover effects, transitions, and micro-interactions
- **Professional Color Scheme**: Gradient themes with soft shadows
- **Toast Notifications**: User-friendly feedback system

### 👤 User Authentication
- User registration and login
- Password hashing with Werkzeug
- Session management
- Protected routes
- Profile management

### 📅 Event Management
- Create, read, update, delete events
- Event categories (Conference, Workshop, Meetup, etc.)
- Image upload support
- Date/time validation
- Rich event descriptions

### 🎯 RSVP System
- One-click RSVP functionality
- Attendee list management
- Cancel RSVP option
- Duplicate RSVP prevention
- Real-time attendee count

### 🔍 Search & Filter
- Live search by title/location
- Category filtering
- Date filtering (upcoming/past)
- AJAX-based functionality
- Pagination support

### 🛡️ Security & Error Handling
- SQL injection protection
- Custom error pages (404, 500, 403)
- Input validation
- CSRF protection
- Secure file uploads

## 🚀 Technology Stack

- **Backend**: Python 3.8+, Flask 2.3+
- **Database**: SQLite (development) / MySQL (production)
- **Frontend**: HTML5, CSS3, JavaScript ES6+
- **UI Framework**: Bootstrap 5.3
- **Icons**: Bootstrap Icons
- **Fonts**: Google Fonts (Inter)
- **Deployment**: PythonAnywhere compatible

## 📦 Installation

### Local Development

1. **Clone the repository**
```bash
git clone <repository-url>
cd eventhub
```

2. **Create virtual environment**
```bash
python -m venv venv
# On Windows
venv\Scripts\activate
# On macOS/Linux
source venv/bin/activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Set up environment variables**
```bash
# Create .env file
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///event_planner.db
```

5. **Initialize database**
```bash
python app.py
```

6. **Run the application**
```bash
python app.py
```

Visit `http://localhost:5000` in your browser.

## 🌐 PythonAnywhere Deployment

### Step 1: Upload Files
1. Create a new web app on PythonAnywhere
2. Upload all project files to your home directory
3. Update the `project_home` path in `wsgi.py`

### Step 2: Configure Virtual Environment
```bash
# In PythonAnywhere console
mkvirtualenv --python=python3 eventhub
pip install -r requirements.txt
```

### Step 3: Set Up Database
1. Create a MySQL database in PythonAnywhere
2. Update `DATABASE_URL` in `wsgi.py`:
```python
os.environ['DATABASE_URL'] = 'mysql://yourusername:yourpassword@yourusername.mysql.pythonanywhere-services.com/yourusername$eventhub'
```

### Step 4: Configure Web App
1. Set the virtual environment path
2. Set the WSGI file path to `wsgi.py`
3. Set the working directory
4. Reload the web app

### Step 5: Set Environment Variables
In the "Web" tab, add these variables:
- `SECRET_KEY`: Generate a secure random key
- `DATABASE_URL`: Your MySQL connection string

## 📁 Project Structure

```
eventhub/
├── app.py                 # Main Flask application
├── routes.py              # Application routes
├── wsgi.py               # WSGI configuration for deployment
├── requirements.txt       # Python dependencies
├── README.md             # Project documentation
├── static/
│   ├── css/
│   │   └── style.css    # Custom styles
│   ├── js/
│   │   └── main.js      # JavaScript functionality
│   └── images/
│       └── uploads/     # User uploaded images
└── templates/
    ├── base.html         # Base template
    ├── index.html        # Home page
    ├── auth/
    │   ├── login.html   # Login page
    │   └── register.html # Registration page
    ├── events/
    │   ├── create.html  # Create event
    │   ├── detail.html  # Event details
    │   ├── edit.html    # Edit event
    │   └── my_events.html # User's events
    ├── profile.html      # User profile
    └── errors/
        ├── 404.html      # Not found page
        ├── 403.html      # Access denied
        └── 500.html      # Server error
```

## 🎯 Database Schema

### Users Table
- `id` (Primary Key)
- `name` (String, 100)
- `email` (String, 120, Unique)
- `password` (String, 200)
- `created_at` (DateTime)

### Events Table
- `id` (Primary Key)
- `user_id` (Foreign Key → Users)
- `title` (String, 200)
- `description` (Text)
- `date` (Date)
- `time` (Time)
- `location` (String, 200)
- `category` (String, 50)
- `image` (String, 200)
- `created_at` (DateTime)

### RSVP Table
- `id` (Primary Key)
- `user_id` (Foreign Key → Users)
- `event_id` (Foreign Key → Events)
- `created_at` (DateTime)
- Unique constraint on (user_id, event_id)

## 🔧 Configuration

### Environment Variables
- `SECRET_KEY`: Flask secret key for sessions
- `DATABASE_URL`: Database connection string
- `FLASK_ENV`: Set to 'production' for deployment

### Database Configuration
- **Development**: SQLite (`sqlite:///event_planner.db`)
- **Production**: MySQL (`mysql://user:pass@host/database`)

## 🎨 Customization

### Adding New Categories
Edit the category options in `templates/events/create.html` and `templates/events/edit.html`:
```html
<option value="new-category">New Category</option>
```

### Custom Styling
Modify `static/css/style.css` to customize:
- Color schemes (CSS variables)
- Animation effects
- Responsive breakpoints
- Component styling

### Adding New Features
1. Add routes in `routes.py`
2. Create templates in `templates/`
3. Update navigation in `templates/base.html`
4. Add JavaScript in `static/js/main.js`

## 🚀 Performance Optimization

### Database Optimization
- Add indexes for frequently queried columns
- Use pagination for large datasets
- Implement caching for static content

### Frontend Optimization
- Image compression and lazy loading
- CSS and JavaScript minification
- CDN for Bootstrap and fonts

### Security Best Practices
- Regular dependency updates
- Input sanitization
- Rate limiting for API endpoints
- HTTPS enforcement in production

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Check DATABASE_URL environment variable
   - Ensure MySQL server is running
   - Verify credentials and permissions

2. **Image Upload Issues**
   - Check upload directory permissions
   - Verify file size limits
   - Ensure proper MIME type filtering

3. **Static Files Not Loading**
   - Check static folder permissions
   - Verify URL generation in templates
   - Clear browser cache

4. **Session Issues**
   - Verify SECRET_KEY is set
   - Check browser cookie settings
   - Ensure session timeout configuration

### Debug Mode
Enable debug mode for development:
```python
app.run(debug=True)
```

## 📱 Mobile Responsiveness

The application is fully responsive and works on:
- Desktop (1200px+)
- Tablet (768px-1199px)
- Mobile (320px-767px)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- [Flask](https://flask.palletsprojects.com/) - Web framework
- [Bootstrap](https://getbootstrap.com/) - UI framework
- [Bootstrap Icons](https://icons.getbootstrap.com/) - Icon library
- [Google Fonts](https://fonts.google.com/) - Typography

## 📞 Support

For support and questions:
- Create an issue in the repository
- Check the troubleshooting section
- Review the documentation

---

**EventHub** - Connecting communities through amazing events! 🎉
