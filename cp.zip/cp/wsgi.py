#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
WSGI configuration for EventHub Community Event Planner
Designed for PythonAnywhere deployment

INSTRUCTIONS:
1. Update 'yourusername' in all paths below to your actual PythonAnywhere username
2. Update database connection string with your actual MySQL credentials
3. Generate a new secret key for production
4. Upload this file to your PythonAnywhere account
5. Set this as your WSGI file in the Web tab
"""

import os
import sys

# ====== UPDATE THIS: Replace 'yourusername' with your PythonAnywhere username ======
YOUR_USERNAME = 'yourusername'
# =====================================================================

# Add project directory to Python path
project_home = f'/home/{YOUR_USERNAME}/eventhub'
if project_home not in sys.path:
    sys.path = [project_home] + sys.path

# Change to project directory
os.chdir(project_home)

# Import Flask app
from app import app as application

# Configure for production
application.config['DEBUG'] = False
application.config['TESTING'] = False

# Set up logging
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s %(message)s',
    handlers=[
        logging.FileHandler(f'/home/{YOUR_USERNAME}/eventhub/error.log'),
        logging.StreamHandler()
    ]
)

# ====== DATABASE CONFIGURATION ======
# SQLite (Recommended for Free Accounts) - No setup required!
# Database file will be created automatically at: /home/yourusername/eventhub/event_planner.db

# MySQL (Paid Accounts Only) - Uncomment and update with your credentials
# if not os.environ.get('DATABASE_URL'):
#     os.environ['DATABASE_URL'] = f'mysql://{YOUR_USERNAME}:yourpassword@{YOUR_USERNAME}.mysql.pythonanywhere-services.com/{YOUR_USERNAME}$eventhub'

# SQLite is automatically configured in config.py for development
# No database setup needed for free PythonAnywhere accounts!

# ====== UPDATE THIS: Generate a secure secret key ======
# Use: python -c "import secrets; print(secrets.token_hex(32))"
if not os.environ.get('SECRET_KEY'):
    os.environ['SECRET_KEY'] = 'your-production-secret-key-here-change-this'

# Initialize database
with application.app_context():
    from app import db
    try:
        db.create_all()
        print("✅ Database tables created successfully")
    except Exception as e:
        print(f"❌ Database creation error: {e}")

print("🚀 WSGI application loaded successfully")
print(f"📁 Project directory: {project_home}")
print(f"🔗 Database URL configured: {'✅' if os.environ.get('DATABASE_URL') else '❌'}")
print(f"🔐 Secret Key configured: {'✅' if os.environ.get('SECRET_KEY') else '❌'}")
